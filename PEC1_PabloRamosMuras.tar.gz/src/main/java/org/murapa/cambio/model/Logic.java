package org.murapa.cambio.model;

public interface Logic {

    String change();

}
